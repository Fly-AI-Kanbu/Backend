# db 연동 계정

mysql_user = "root"
mysql_password = "kanbu"
mysql_ip = "localhost"
mysql_db = "kanbu"